import pandas as pd
import numpy as np
from sklearn.preprocessing import normalize
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib
import json

# === Step 1: Load Data ===
df = pd.read_csv("cleaned_merged_permission_feature_vectors.csv")

# === Step 2: Clean & Preprocess ===
df['type'] = df['type'].str.strip().str.lower()
df['category'] = df['category'].fillna('unknown').str.strip().str.lower()
df['family'] = df['family'].fillna('unknown').str.strip().str.lower()

# Drop rows with missing type
df = df.dropna(subset=['type'])

# === Step 3: Feature/Target Prep ===
metadata_cols = ['md5', 'sha256', 'type', 'category', 'family', 'VT_positives', 'VT_engines']
permission_cols = [col for col in df.columns if col not in metadata_cols]

X = df[permission_cols]
X_norm = pd.DataFrame(normalize(X, norm='l1'), columns=permission_cols)
final_df = pd.concat([df[['md5', 'sha256', 'type', 'category', 'family']], X_norm], axis=1)

# === Stage 1: Type Classifier ===
X_type = final_df[permission_cols]
y_type = final_df['type']

X_train, X_test, y_train, y_test = train_test_split(
    X_type, y_type, test_size=0.2, random_state=42, stratify=y_type
)

rf_type = RandomForestClassifier(n_estimators=100, random_state=42)
rf_type.fit(X_train, y_train)

joblib.dump(rf_type, "rf_type_permission_classifier.joblib")
print("\n📌 Stage 1: Type Classifier Trained")
print(classification_report(y_test, rf_type.predict(X_test)))

# === Stage 2: Category Classifier (on malware only) ===
df_malware = final_df[final_df['type'] == 'malware']
X_cat = df_malware[permission_cols]
y_cat = df_malware['category']

if len(y_cat.unique()) > 1:
    X_train_cat, X_test_cat, y_train_cat, y_test_cat = train_test_split(
        X_cat, y_cat, test_size=0.2, random_state=42, stratify=y_cat
    )

    rf_cat = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_cat.fit(X_train_cat, y_train_cat)
    joblib.dump(rf_cat, "rf_category_permission_classifier.joblib")

    print("\n📌 Stage 2: Category Classifier Trained")
    print(classification_report(y_test_cat, rf_cat.predict(X_test_cat)))
else:
    print("⚠️ Not enough unique categories to train category classifier.")

# === Stage 3: Family Classifier (on malware only) ===
y_fam = df_malware['family']

if len(y_fam.unique()) > 1:
    X_train_fam, X_test_fam, y_train_fam, y_test_fam = train_test_split(
        X_cat, y_fam, test_size=0.2, random_state=42, stratify=y_fam
    )

    rf_fam = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_fam.fit(X_train_fam, y_train_fam)
    joblib.dump(rf_fam, "rf_family_permission_classifier.joblib")

    print("\n📌 Stage 3: Family Classifier Trained")
    print(classification_report(y_test_fam, rf_fam.predict(X_test_fam)))
else:
    print("⚠️ Not enough unique families to train family classifier.")

# === Save the permission feature list ===
with open("permission_columns.json", "w") as f:
    json.dump(permission_cols, f)

print("\n✅ All models and feature list saved.")
