import json
import pandas as pd
import numpy as np
import joblib

# === Step 1: Load JSON input ===
json_file = input("Enter path to JSON file: ")
with open(json_file, "r") as f:
    data = json.load(f)

# === Step 2: Load trained models ===
rf_type = joblib.load("rf_type_permission_classifier.joblib")
rf_category = joblib.load("rf_category_permission_classifier.joblib")
rf_family = joblib.load("rf_family_permission_classifier.joblib")

with open("permission_columns.json", "r") as f:
    permission_columns = json.load(f)

# === Step 3: Extract permissions from JSON ===
permissions = data.get("Static_analysis", {}).get("Permissions", [])
permissions = [perm.strip() for perm in permissions]

# === Step 4: Build binary permission vector ===
perm_vector = {perm: 0 for perm in permission_columns}
for p in permissions:
    if p in perm_vector:
        perm_vector[p] = 1

df_input = pd.DataFrame([perm_vector])

# === Step 5: Predict type with confidence threshold ===
proba = rf_type.predict_proba(df_input)[0]
pred_idx = np.argmax(proba)
predicted_type = rf_type.classes_[pred_idx]
confidence = proba[pred_idx]

# Optional: Adjust threshold
if predicted_type == "malware" and confidence < 0.65:
    predicted_type = "benign"

print(f"\n📌 Predicted Type: {predicted_type} (Confidence: {confidence:.2f})")

# === Step 6: Predict category and family if malware ===
if predicted_type == "malware":
    predicted_category = rf_category.predict(df_input)[0]
    predicted_family = rf_family.predict(df_input)[0]

    print(f"📌 Predicted Category: {predicted_category}")
    print(f"📌 Predicted Malware Family: {predicted_family}")
else:
    print("✅ This app is predicted as benign.")
