import pandas as pd
from pycaret.classification import *

# === Step 1: Load Data ===
df = pd.read_csv("cleaned_merged_permission_feature_vectors.csv")

# === Step 2: Clean & Preprocess ===
df['type'] = df['type'].str.strip().str.lower()
df['category'] = df['category'].fillna('unknown').str.strip().str.lower()
df['family'] = df['family'].fillna('unknown').str.strip().str.lower()
df = df.dropna(subset=['type'])  # Drop rows with missing target

# === Step 3: Feature/Target Prep ===
metadata_cols = ['md5', 'sha256', 'type', 'category', 'family', 'VT_positives', 'VT_engines']
permission_cols = [col for col in df.columns if col not in metadata_cols]
X = df[permission_cols]

# Normalize if required (optional for PyCaret)
# from sklearn.preprocessing import normalize
# X_norm = pd.DataFrame(normalize(X, norm='l1'), columns=permission_cols)

# Prepare final dataframe
final_df = pd.concat([df[['type']], X], axis=1)

# === Step 4: Initialize PyCaret Setup ===
clf_setup = setup(
    data=final_df,
    target='type',
    normalize=True,
    session_id=123,
    use_gpu=True  # Optional
)


# === Step 5: Compare Models ===
best_model = compare_models()

# === Step 6: Output Best Model Info ===
print(best_model)
