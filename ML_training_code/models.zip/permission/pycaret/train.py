import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import classification_report
from joblib import dump

# === Step 1: Load and Clean Dataset ===
df = pd.read_csv('cleaned_merged_permission_feature_vectors.csv')
df = df.dropna(subset=['type'])  # type is mandatory
df['type'] = df['type'].str.lower().str.strip()
df['category'] = df['category'].fillna('unknown').str.lower().str.strip()
df['family'] = df['family'].fillna('unknown').str.lower().str.strip()

non_feature_cols = ['md5', 'sha256', 'type', 'category', 'family', 'VT_positives', 'VT_engines']
X = df.drop(columns=non_feature_cols).select_dtypes(include=[np.number])

# === Step 2: Scaling (using StandardScaler as an alternative) ===
scaler = StandardScaler()  # You can also try MinMaxScaler here
X_scaled = scaler.fit_transform(X)

# === Step 3: Check label distribution ===
print("Label distribution for 'type':")
print(df['type'].value_counts())
print("\nLabel distribution for 'category':")
print(df['category'].value_counts())
print("\nLabel distribution for 'family':")
print(df['family'].value_counts())

# === Step 4: Model Initialization ===
models = {
    'et': ExtraTreesClassifier(n_estimators=100, random_state=42),
    'rf': RandomForestClassifier(n_estimators=100, random_state=42),
    'gbc': GradientBoostingClassifier(n_estimators=100, random_state=42)
}

os.makedirs("saved_models", exist_ok=True)

# === Stage 1: Type Classifier ===
print("\n🚀 Stage 1: Type Classifier (benign vs malware)")
y_type = df['type']
X_train_type, X_test_type, y_train_type, y_test_type = train_test_split(
    X_scaled, y_type, test_size=0.2, stratify=y_type, random_state=42)

for name, model in models.items():
    print(f"\n🧠 Training {name.upper()} for Type Classification")
    if len(np.unique(y_train_type)) < 2:
        print(f"⚠️ Skipping {name.upper()} - only one class in training data")
        continue
    model.fit(X_train_type, y_train_type)
    y_pred = model.predict(X_test_type)
    print(classification_report(y_test_type, y_pred))
    dump(model, f"saved_models/type_classifier_{name}.joblib")

# === Stage 2: Category Classifier (Malware Only) ===
print("\n🚀 Stage 2: Category Classifier (only for malware)")
df_mal = df[df['type'] == 'malware']
X_mal = df_mal.drop(columns=non_feature_cols).select_dtypes(include=[np.number])
X_mal_scaled = scaler.transform(X_mal)
y_cat = df_mal['category']

if len(np.unique(y_cat)) > 1:
    X_train_cat, X_test_cat, y_train_cat, y_test_cat = train_test_split(
        X_mal_scaled, y_cat, test_size=0.2, stratify=y_cat, random_state=42)
    
    for name, model in models.items():
        print(f"\n🧠 Training {name.upper()} for Category Classification")
        if len(np.unique(y_train_cat)) < 2:
            print(f"⚠️ Skipping {name.upper()} - only one class in training data")
            continue
        model.fit(X_train_cat, y_train_cat)
        y_pred = model.predict(X_test_cat)
        print(classification_report(y_test_cat, y_pred))
        dump(model, f"saved_models/category_classifier_{name}.joblib")
else:
    print("⚠️ Not enough category diversity to train")

# === Stage 3: Family Classifier (Malware Only, Excluding 'unknown' Family) ===
print("\n🚀 Stage 3: Family Classifier (only for malware, excluding 'unknown' family)")
df_mal = df[df['type'] == 'malware']
df_mal = df_mal[df_mal['family'] != 'unknown']  # Exclude 'unknown' family for family classification
X_mal = df_mal.drop(columns=non_feature_cols).select_dtypes(include=[np.number])
X_mal_scaled = scaler.transform(X_mal)
y_fam = df_mal['family']

if len(np.unique(y_fam)) > 1:
    X_train_fam, X_test_fam, y_train_fam, y_test_fam = train_test_split(
        X_mal_scaled, y_fam, test_size=0.2, stratify=y_fam, random_state=42)
    
    for name, model in models.items():
        print(f"\n🧠 Training {name.upper()} for Family Classification")
        if len(np.unique(y_train_fam)) < 2:
            print(f"⚠️ Skipping {name.upper()} - only one class in training data")
            continue
        model.fit(X_train_fam, y_train_fam)
        y_pred = model.predict(X_test_fam)
        print(classification_report(y_test_fam, y_pred))
        dump(model, f"saved_models/family_classifier_{name}.joblib")
else:
    print("⚠️ Not enough family diversity to train")

# === Save Scaler ===
dump(scaler, "saved_models/permission_scaler.joblib")
print("\n✅ All models and scaler saved to 'saved_models/' directory.")
