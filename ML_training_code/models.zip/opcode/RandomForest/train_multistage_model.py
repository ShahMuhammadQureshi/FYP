import pandas as pd
import numpy as np
from sklearn.preprocessing import normalize
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib
import json

# === Step 1: Load & Clean Data ===
df = pd.read_csv("merged_opcode_feature_vectors.csv", header=None)
df.columns = ['md5', 'sha256', 'type', 'category', 'family', 'VT_positives', 'VT_engines', 'opcode', 'count']

# Remove bad rows where 'type' column was accidentally written as a value
df = df[df['type'].str.lower() != 'type']

# Drop rows with missing critical info
df = df.dropna(subset=['type', 'opcode', 'count'])

# Force count to be numeric
df['count'] = pd.to_numeric(df['count'], errors='coerce').fillna(0).astype(int)

# Clean text columns
df['type'] = df['type'].str.strip().str.lower()
df['category'] = df['category'].fillna('unknown').str.strip().str.lower()
df['family'] = df['family'].fillna('unknown').str.strip().str.lower()

# === Step 2: Pivot to Wide Format ===
pivot_df = df.pivot_table(
    index=['md5', 'sha256', 'type', 'category', 'family'],
    columns='opcode',
    values='count',
    aggfunc='sum',
    fill_value=0
).reset_index()

# === Step 3: Normalize Opcode Columns ===
metadata_cols = ['md5', 'sha256', 'type', 'category', 'family']
X = pivot_df.drop(columns=metadata_cols)
X = X.apply(pd.to_numeric, errors='coerce').fillna(0)

X_norm = pd.DataFrame(normalize(X, norm='l1'), columns=X.columns)
final_df = pd.concat([pivot_df[metadata_cols], X_norm], axis=1)

# === Step 4: Train Type Classifier ===
X_type = final_df.drop(columns=metadata_cols)
y_type = final_df['type']
X_train, X_test, y_train, y_test = train_test_split(X_type, y_type, test_size=0.2, random_state=42, stratify=y_type)

rf_type = RandomForestClassifier(n_estimators=100, random_state=42)
rf_type.fit(X_train, y_train)
joblib.dump(rf_type, "rf_type_classifier.joblib")
print("\n📌 Stage 1: Type Classifier Trained")
print(classification_report(y_test, rf_type.predict(X_test)))

# === Step 5: Train Category Classifier (on malware only) ===
df_malware = final_df[final_df['type'] == 'malware']
X_cat = df_malware.drop(columns=metadata_cols)
y_cat = df_malware['category']

if len(y_cat.unique()) > 1:
    X_train_cat, X_test_cat, y_train_cat, y_test_cat = train_test_split(X_cat, y_cat, test_size=0.2, random_state=42, stratify=y_cat)
    rf_cat = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_cat.fit(X_train_cat, y_train_cat)
    joblib.dump(rf_cat, "rf_category_classifier.joblib")
    print("\n📌 Stage 2: Category Classifier Trained")
    print(classification_report(y_test_cat, rf_cat.predict(X_test_cat)))
else:
    print("⚠️ Not enough category classes to train category classifier.")

# === Step 6: Train Family Classifier (on malware only) ===
y_fam = df_malware['family']

if len(y_fam.unique()) > 1:
    X_train_fam, X_test_fam, y_train_fam, y_test_fam = train_test_split(X_cat, y_fam, test_size=0.2, random_state=42, stratify=y_fam)
    rf_fam = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_fam.fit(X_train_fam, y_train_fam)
    joblib.dump(rf_fam, "rf_family_classifier.joblib")
    print("\n📌 Stage 3: Family Classifier Trained")
    print(classification_report(y_test_fam, rf_fam.predict(X_test_fam)))
else:
    print("⚠️ Not enough family classes to train family classifier.")


# Save opcode feature column names for later use in prediction
opcode_columns = X.columns.tolist()
with open("opcode_columns.json", "w") as f:
    json.dump(opcode_columns, f)
