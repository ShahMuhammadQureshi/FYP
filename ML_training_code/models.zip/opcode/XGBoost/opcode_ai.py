import json
import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import normalize

# === Step 1: Prompt for JSON input ===
json_filename = input("Enter path to JSON report file: ")
with open(json_filename, "r") as f:
    data = json.load(f)

# === Step 2: Load models and encoders ===
rf_type = joblib.load("rf_type_classifier.joblib")
rf_category = joblib.load("rf_category_classifier.joblib")
rf_family = joblib.load("rf_family_classifier.joblib")

le_type = joblib.load("label_encoder_type.joblib")
le_category = joblib.load("label_encoder_category.joblib")
le_family = joblib.load("label_encoder_family.joblib")

# === Step 3: Load opcode columns ===
with open("opcode_columns.json", "r") as f:
    opcode_columns = json.load(f)

# === Step 4: Build opcode vector ===
opcode_counts = data["Static_analysis"]["Opcodes"]
opcode_vector = {opcode: 0 for opcode in opcode_columns}
opcode_vector.update({op: count for op, count in opcode_counts.items() if op in opcode_vector})

df_input = pd.DataFrame([opcode_vector])
df_input = df_input.apply(pd.to_numeric, errors='coerce').fillna(0)
df_input_norm = pd.DataFrame(normalize(df_input, norm='l1'), columns=opcode_columns)

# === Step 5: Predict type (malware/benign) ===
type_pred_encoded = rf_type.predict(df_input_norm)[0]
predicted_type = le_type.inverse_transform([type_pred_encoded])[0]
print(f"\n📌 Predicted Type: {predicted_type}")

# === Step 6: Predict category + family (if malware) ===
if predicted_type == "malware":
    category_pred_encoded = rf_category.predict(df_input_norm)[0]
    predicted_category = le_category.inverse_transform([category_pred_encoded])[0]

    family_pred_encoded = rf_family.predict(df_input_norm)[0]
    predicted_family = le_family.inverse_transform([family_pred_encoded])[0]

    print(f"📌 Predicted Category: {predicted_category}")
    print(f"📌 Predicted Malware Family: {predicted_family}")
else:
    print("✅ This app is predicted as benign.")
