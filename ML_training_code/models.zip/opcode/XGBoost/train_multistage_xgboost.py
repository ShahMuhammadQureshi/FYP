import pandas as pd
import numpy as np
import joblib
import json
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.preprocessing import normalize, LabelEncoder
from xgboost import XGBClassifier

# === Step 1: Load and preprocess data ===
df = pd.read_csv("merged_opcode_feature_vectors.csv", header=None)
df.columns = ['md5', 'sha256', 'type', 'category', 'family', 'VT_positives', 'VT_engines', 'opcode', 'count']
df = df[df['type'].str.lower() != 'type']
df = df.dropna(subset=['type', 'opcode', 'count'])
df['count'] = pd.to_numeric(df['count'], errors='coerce').fillna(0).astype(int)
df['type'] = df['type'].str.strip().str.lower()
df['category'] = df['category'].fillna('unknown').str.strip().str.lower()
df['family'] = df['family'].fillna('unknown').str.strip().str.lower()

pivot_df = df.pivot_table(
    index=['md5', 'sha256', 'type', 'category', 'family'],
    columns='opcode',
    values='count',
    aggfunc='sum',
    fill_value=0
).reset_index()

# === Step 2: Normalize ===
metadata_cols = ['md5', 'sha256', 'type', 'category', 'family']
X = pivot_df.drop(columns=metadata_cols).apply(pd.to_numeric, errors='coerce').fillna(0)
X_norm = pd.DataFrame(normalize(X, norm='l1'), columns=X.columns)
final_df = pd.concat([pivot_df[metadata_cols], X_norm], axis=1)

# === Stage 1: Type Classifier ===
X_type = final_df.drop(columns=metadata_cols)
y_type = final_df['type']
le_type = LabelEncoder()
y_type_encoded = le_type.fit_transform(y_type)

X_train, X_test, y_train, y_test = train_test_split(
    X_type, y_type_encoded, test_size=0.2, stratify=y_type_encoded, random_state=42
)

xgb_type = XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42)
xgb_type.fit(X_train, y_train)
joblib.dump(xgb_type, "rf_type_classifier.joblib")
joblib.dump(le_type, "label_encoder_type.joblib")

print("\n📌 Stage 1: Type Classifier Trained")
print(classification_report(y_test, xgb_type.predict(X_test), target_names=le_type.classes_))

# === Stage 2: Category Classifier (on malware only) ===
df_malware = final_df[final_df['type'] == 'malware']
X_cat = df_malware.drop(columns=metadata_cols)
y_cat = df_malware['category']
le_cat = LabelEncoder()
y_cat_encoded = le_cat.fit_transform(y_cat)

if len(le_cat.classes_) > 1:
    X_train_cat, X_test_cat, y_train_cat, y_test_cat = train_test_split(
        X_cat, y_cat_encoded, test_size=0.2, stratify=y_cat_encoded, random_state=42
    )
    xgb_cat = XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42)
    xgb_cat.fit(X_train_cat, y_train_cat)
    joblib.dump(xgb_cat, "rf_category_classifier.joblib")
    joblib.dump(le_cat, "label_encoder_category.joblib")

    print("\n📌 Stage 2: Category Classifier Trained")
    print(classification_report(y_test_cat, xgb_cat.predict(X_test_cat), target_names=le_cat.classes_))
else:
    print("⚠️ Not enough category classes to train.")

# === Stage 3: Family Classifier (on malware only) ===
y_fam = df_malware['family']
le_fam = LabelEncoder()
y_fam_encoded = le_fam.fit_transform(y_fam)

if len(le_fam.classes_) > 1:
    X_train_fam, X_test_fam, y_train_fam, y_test_fam = train_test_split(
        X_cat, y_fam_encoded, test_size=0.2, stratify=y_fam_encoded, random_state=42
    )
    xgb_fam = XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42)
    xgb_fam.fit(X_train_fam, y_train_fam)
    joblib.dump(xgb_fam, "rf_family_classifier.joblib")
    joblib.dump(le_fam, "label_encoder_family.joblib")

    print("\n📌 Stage 3: Family Classifier Trained")
    print(classification_report(y_test_fam, xgb_fam.predict(X_test_fam), target_names=le_fam.classes_))
else:
    print("⚠️ Not enough family classes to train.")

# === Save Opcode Columns ===
opcode_columns = X.columns.tolist()
with open("opcode_columns.json", "w") as f:
    json.dump(opcode_columns, f)
