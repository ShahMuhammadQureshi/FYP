import pandas as pd
from sklearn.preprocessing import normalize
from pycaret.classification import *

# === Step 1: Load & Clean Data ===
df = pd.read_csv("merged_opcode_feature_vectors.csv", header=None)
df.columns = ['md5', 'sha256', 'type', 'category', 'family', 'VT_positives', 'VT_engines', 'opcode', 'count']

# Remove bad header rows
df = df[df['type'].str.lower() != 'type']

# Drop missing values and clean count
df = df.dropna(subset=['type', 'opcode', 'count'])
df['count'] = pd.to_numeric(df['count'], errors='coerce').fillna(0).astype(int)

# Clean text columns
df['type'] = df['type'].str.strip().str.lower()
df['category'] = df['category'].fillna('unknown').str.strip().str.lower()
df['family'] = df['family'].fillna('unknown').str.strip().str.lower()

# === Step 2: Pivot to Opcode Features ===
pivot_df = df.pivot_table(
    index=['md5', 'sha256', 'type', 'category', 'family'],
    columns='opcode',
    values='count',
    aggfunc='sum',
    fill_value=0
).reset_index()

# === Step 3: Normalize Opcode Counts ===
metadata_cols = ['md5', 'sha256', 'type', 'category', 'family']
X = pivot_df.drop(columns=metadata_cols).apply(pd.to_numeric, errors='coerce').fillna(0)
X_norm = pd.DataFrame(normalize(X, norm='l1'), columns=X.columns)

# Combine normalized opcodes with labels
final_df = pd.concat([pivot_df[['type']], X_norm], axis=1)

# === Step 4: PyCaret Setup ===
clf_setup = setup(
    data=final_df,
    target='type',
    normalize=False,  # Already normalized manually
    session_id=123,
    use_gpu=True
)

# === Step 5: Train & Compare Models ===
best_model = compare_models()

# === Step 6: Print Best Model ===
print(best_model)
