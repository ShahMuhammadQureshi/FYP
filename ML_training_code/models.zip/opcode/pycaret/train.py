import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.preprocessing import normalize, LabelEncoder
from sklearn.ensemble import ExtraTreesClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
import joblib
import json
import os
import re

# ========== Setup ==========
os.makedirs("saved_models", exist_ok=True)

# ========== Step 1: Load & Clean Data ==========
df = pd.read_csv("merged_opcode_feature_vectors.csv", header=None, low_memory=False)
df.columns = ['md5', 'sha256', 'type', 'category', 'family', 'VT_positives', 'VT_engines', 'opcode', 'count']

# Remove bad header rows and clean
df = df[df['type'].str.lower() != 'type']
df = df.dropna(subset=['type', 'opcode', 'count'])
df['count'] = pd.to_numeric(df['count'], errors='coerce').fillna(0).astype(int)
df['type'] = df['type'].str.strip().str.lower()
df['category'] = df['category'].fillna('unknown').str.strip().str.lower()
df['family'] = df['family'].fillna('unknown').str.strip().str.lower()

# ========== Step 2: Pivot ==========
pivot_df = df.pivot_table(
    index=['md5', 'sha256', 'type', 'category', 'family'],
    columns='opcode',
    values='count',
    aggfunc='sum',
    fill_value=0
)

# ========== ⚠️ IMPORTANT FIX: Clean opcode column names ==========
def clean_column_name(name):
    return str(name).replace('"', '_').replace('\\', '_').replace('/', '_').replace('$', '_')

pivot_df.columns = [clean_column_name(col) if not isinstance(col, tuple) else col for col in pivot_df.columns]
pivot_df = pivot_df.reset_index()

# ========== Step 3: Normalize ==========
metadata_cols = ['md5', 'sha256', 'type', 'category', 'family']
X_raw = pivot_df.drop(columns=metadata_cols).apply(pd.to_numeric, errors='coerce').fillna(0)

# Normalize and keep same feature names
X_norm = pd.DataFrame(normalize(X_raw, norm='l1'), columns=X_raw.columns)
final_df = pd.concat([pivot_df[metadata_cols], X_norm], axis=1)

# Save opcode column names
opcode_columns = X_raw.columns.tolist()
with open("saved_models/opcode_columns.json", "w") as f:
    json.dump(opcode_columns, f)

# ========== Helper: Train & Save Model ==========
def train_and_save_model(model, X, y, model_name):
    label_encoder = None
    if y.dtype == 'object' or y.dtype.name == 'category':
        label_encoder = LabelEncoder()
        y = label_encoder.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, stratify=y, test_size=0.2, random_state=42)


    # Replace special characters in column names
    X_train.columns = [re.sub(r'[^\w]', '_', col) for col in X_train.columns]
    X_test.columns = [re.sub(r'[^\w]', '_', col) for col in X_test.columns]

    model.fit(X_train, y_train)
    joblib.dump(model, f"saved_models/{model_name}.joblib")

    y_pred = model.predict(X_test)
    if label_encoder:
        y_test = label_encoder.inverse_transform(y_test)
        y_pred = label_encoder.inverse_transform(y_pred)
        joblib.dump(label_encoder, f"saved_models/{model_name}_label_encoder.joblib")

    print(f"\n📌 {model_name} trained")
    print(classification_report(y_test, y_pred))

# ========== Stage 1: Type ==========
X_type = final_df.drop(columns=metadata_cols)
y_type = final_df['type']

train_and_save_model(ExtraTreesClassifier(random_state=42), X_type, y_type, "et_type_classifier")
train_and_save_model(XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42), X_type, y_type, "xgb_type_classifier")
train_and_save_model(LGBMClassifier(random_state=42), X_type, y_type, "lgbm_type_classifier")

# ========== Stage 2: Category (malware only) ==========
df_malware = final_df[final_df['type'] == 'malware']
X_cat = df_malware.drop(columns=metadata_cols)
y_cat = df_malware['category']

if len(y_cat.unique()) > 1:
    train_and_save_model(ExtraTreesClassifier(random_state=42), X_cat, y_cat, "et_category_classifier")
    train_and_save_model(XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42), X_cat, y_cat, "xgb_category_classifier")
    train_and_save_model(LGBMClassifier(random_state=42), X_cat, y_cat, "lgbm_category_classifier")
else:
    print("⚠️ Not enough category classes to train.")

# ========== Stage 3: Family (malware only) ==========
y_fam = df_malware['family']

if len(y_fam.unique()) > 1:
    train_and_save_model(ExtraTreesClassifier(random_state=42), X_cat, y_fam, "et_family_classifier")
    train_and_save_model(XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42), X_cat, y_fam, "xgb_family_classifier")
    train_and_save_model(LGBMClassifier(random_state=42), X_cat, y_fam, "lgbm_family_classifier")
else:
    print("⚠️ Not enough family classes to train.")
