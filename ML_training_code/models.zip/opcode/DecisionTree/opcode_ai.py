import json
import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import normalize

# === Step 1: Prompt for input JSON report ===
json_filename = input("Enter path to JSON report file: ")
with open(json_filename, "r") as f:
    data = json.load(f)

# === Step 2: Load trained models ===
rf_type = joblib.load("rf_type_classifier.joblib")
rf_category = joblib.load("rf_category_classifier.joblib")
rf_family = joblib.load("rf_family_classifier.joblib")

# === Step 3: Load opcode feature column names ===
with open("opcode_columns.json", "r") as f:
    opcode_columns = json.load(f)

# === Step 4: Extract opcode vector ===
opcode_counts = data["Static_analysis"]["Opcodes"]
opcode_vector = {opcode: 0 for opcode in opcode_columns}
opcode_vector.update({op: count for op, count in opcode_counts.items() if op in opcode_vector})

# === Step 5: Normalize input
df_input = pd.DataFrame([opcode_vector])
df_input = df_input.apply(pd.to_numeric, errors='coerce').fillna(0)
df_input_norm = pd.DataFrame(normalize(df_input, norm='l1'), columns=opcode_columns)

# === Step 6: Stage 1 - Type Classification
predicted_type = rf_type.predict(df_input_norm)[0]
print(f"\n📌 Predicted Type: {predicted_type}")

# === Step 7: Stage 2 + 3 - If malware, predict category and family
if predicted_type == "malware":
    predicted_category = rf_category.predict(df_input_norm)[0]
    predicted_family = rf_family.predict(df_input_norm)[0]
    print(f"📌 Predicted Category: {predicted_category}")
    print(f"📌 Predicted Malware Family: {predicted_family}")
else:
    print("✅ This app is predicted as benign.")
